1) 
Add 
alias killsound "playvideo killsound 1 1 1; playvideo killsound 1 1 1"
into your autoexec.cfg file in your Titanfall2\r2\cfg folder. If it's not there, create one and add it in.

2) 
go to Titanfall2\ns_startupargs.txt and add in: +exec autoexec.cfg

3) 
extract and drag the rest of the files into your Titanfall folder



It should work now when you kill someone.
